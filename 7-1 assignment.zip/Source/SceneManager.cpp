﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ================
// manage preparing and rendering of 3D scenes: textures, materials, lighting
//
// AUTHOR: Christopher Phillips / Computer Science
// Updated to correct signature mismatches and implement missing methods
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include "../3DShapes/ShapeMeshes.h"
#include <GL/glew.h>               // for GLuint, gl* functions

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <iostream>
#include <vector> 
#include <glm/gtx/transform.hpp>

// uniform names (must match your shaders)
namespace {
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

//==============================================================================
// Constructor / Destructor
//==============================================================================
SceneManager::SceneManager(ShaderManager* pShaderManager)
    : m_pShaderManager(pShaderManager),
    m_basicMeshes(new ShapeMeshes()),
    m_loadedTextures(0)
{
}

SceneManager::~SceneManager()
{
    DestroyGLTextures();
    delete m_basicMeshes;
    m_basicMeshes = nullptr;
    m_pShaderManager = nullptr;
}

//==============================================================================
// Texture Loading / Binding / Cleanup
//==============================================================================
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, channels = 0;
    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (!image) {
        std::cout << "Failed to load texture: " << filename << std::endl;
        return false;
    }

    GLuint texID;
    glGenTextures(1, &texID);
    glBindTexture(GL_TEXTURE_2D, texID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    GLenum fmt = (channels == 4 ? GL_RGBA : GL_RGB);
    glTexImage2D(GL_TEXTURE_2D, 0, (channels == 4 ? GL_RGBA8 : GL_RGB8), width, height, 0, fmt, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    m_textureIDs[m_loadedTextures] = { static_cast<uint32_t>(texID), tag };
    m_loadedTextures++;
    return true;
}

void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i) {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
        glDeleteTextures(1, &m_textureIDs[i].ID);
    m_loadedTextures = 0;
}

//==============================================================================
// Helpers
//==============================================================================
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
        if (m_textureIDs[i].tag == tag)
            return i;
    return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& out)
{
    for (auto& mat : m_objectMaterials)
        if (mat.tag == tag) { out = mat; return true; }
    return false;
}

//==============================================================================
// Uniform setters
//==============================================================================
void SceneManager::SetTransformations(glm::vec3 scaleXYZ,
    float Xdeg, float Ydeg, float Zdeg,
    glm::vec3 pos)
{
    glm::mat4 model = glm::translate(pos)
        * glm::rotate(glm::radians(Zdeg), glm::vec3(0, 0, 1))
        * glm::rotate(glm::radians(Ydeg), glm::vec3(0, 1, 0))
        * glm::rotate(glm::radians(Xdeg), glm::vec3(1, 0, 0))
        * glm::scale(scaleXYZ);
    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, 0);
        m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
    }
}

void SceneManager::SetShaderTexture(std::string tag)
{
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, 1);
        int slot = FindTextureSlot(tag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
    }
}

void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

void SceneManager::SetShaderMaterial(std::string tag)
{
    OBJECT_MATERIAL mat;
    if (m_pShaderManager && FindMaterial(tag, mat)) {
        m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
    }
}

//==============================================================================
// Scene setup
//==============================================================================
void SceneManager::LoadSceneTextures()
{
    CreateGLTexture("Textures/grass.jpg", "grass");
    CreateGLTexture("Textures/metal.jpg", "metal");
    CreateGLTexture("Textures/brick.jpg", "brick");
    CreateGLTexture("Textures/water.png", "water");
    CreateGLTexture("Textures/poolWall.jpg", "poolWall");
}

void SceneManager::DefineObjectMaterials()
{
    // Gold material
    OBJECT_MATERIAL gold;
    gold.tag = "gold";
    gold.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
    gold.ambientStrength = 0.4f;
    gold.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
    gold.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
    gold.shininess = 22.0f;
    m_objectMaterials.push_back(gold);

    // Cement material
    OBJECT_MATERIAL cement;
    cement.tag = "cement";
    cement.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
    cement.ambientStrength = 0.2f;
    cement.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
    cement.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
    cement.shininess = 0.5f;
    m_objectMaterials.push_back(cement);

    // Wood material
    OBJECT_MATERIAL wood;
    wood.tag = "wood";
    wood.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
    wood.ambientStrength = 0.2f;
    wood.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
    wood.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
    wood.shininess = 0.3f;
    m_objectMaterials.push_back(wood);

    // Tile material
    OBJECT_MATERIAL tile;
    tile.tag = "tile";
    tile.ambientColor = glm::vec3(0.2f, 0.3f, 0.4f);
    tile.ambientStrength = 0.3f;
    tile.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
    tile.specularColor = glm::vec3(0.4f, 0.5f, 0.6f);
    tile.shininess = 25.0f;
    m_objectMaterials.push_back(tile);

    // Glass material
    OBJECT_MATERIAL glass;
    glass.tag = "glass";
    glass.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
    glass.ambientStrength = 0.3f;
    glass.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
    glass.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
    glass.shininess = 85.0f;
    m_objectMaterials.push_back(glass);

    // Clay material
    OBJECT_MATERIAL clay;
    clay.tag = "clay";
    clay.ambientColor = glm::vec3(0.2f, 0.2f, 0.3f);
    clay.ambientStrength = 0.3f;
    clay.diffuseColor = glm::vec3(0.4f, 0.4f, 0.5f);
    clay.specularColor = glm::vec3(0.2f, 0.2f, 0.4f);
    clay.shininess = 0.5f;
    m_objectMaterials.push_back(clay);

    OBJECT_MATERIAL poolMat;
    poolMat.tag = "pool";
    poolMat.ambientColor = glm::vec3(0.05f, 0.1f, 0.3f);
    poolMat.ambientStrength = 0.3f;
    poolMat.diffuseColor = glm::vec3(0.1f, 0.3f, 0.7f);
    poolMat.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
    poolMat.shininess = 16.0f;
    m_objectMaterials.push_back(poolMat);
}

void SceneManager::SetupSceneLights()
{
    if (!m_pShaderManager) return;

    // Light #0
    m_pShaderManager->setVec3Value("lightSources[0].position",
        glm::vec3(3.0f, 14.0f, 0.0f));
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor",
        glm::vec3(0.01f, 0.01f, 0.01f));
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor",
        glm::vec3(0.40f, 0.40f, 0.40f));
    m_pShaderManager->setVec3Value("lightSources[0].specularColor",
        glm::vec3(0.00f, 0.00f, 0.00f));
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.05f);

    // Light #1
    m_pShaderManager->setVec3Value("lightSources[1].position",
        glm::vec3(-3.0f, 14.0f, 0.0f));
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor",
        glm::vec3(0.01f, 0.01f, 0.01f));
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor",
        glm::vec3(0.40f, 0.40f, 0.40f));
    m_pShaderManager->setVec3Value("lightSources[1].specularColor",
        glm::vec3(0.00f, 0.00f, 0.00f));
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 32.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.05f);

    // Light #2
    m_pShaderManager->setVec3Value("lightSources[2].position",
        glm::vec3(0.6f, 5.0f, 6.0f));
    m_pShaderManager->setVec3Value("lightSources[2].ambientColor",
        glm::vec3(0.01f, 0.01f, 0.01f));
    m_pShaderManager->setVec3Value("lightSources[2].diffuseColor",
        glm::vec3(0.30f, 0.30f, 0.30f));
    m_pShaderManager->setVec3Value("lightSources[2].specularColor",
        glm::vec3(0.30f, 0.30f, 0.30f));
    m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 12.0f);
    m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.50f);

    // Turn lighting on in the shader
    m_pShaderManager->setBoolValue("bUseLighting", true);
}

void SceneManager::PrepareScene()
{
    // 1) load and bind textures
    LoadSceneTextures();
    BindGLTextures();

    // 2) set up all materials (ambient/diffuse/specular/shininess)
    DefineObjectMaterials();

    // 3) configure your three lightSources[]
    SetupSceneLights();

    // 4) load every mesh you plan to draw
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    // …also cone/sphere if you’ll use them later…
}

void SceneManager::RenderScene()
{
    // Ground: grass on cement
    SetShaderTexture("grass");
    SetShaderMaterial("cement");
    SetTextureUVScale(10.0f, 10.0f);
    {
        // define the two locals you need
        glm::vec3 scaleGround(20.0f, 1.0f, 10.0f);
        glm::vec3 groundPos(0.0f, 0.0f, 0.0f);

        // send to the shader
        SetTransformations(scaleGround,
            0.0f, 0.0f, 0.0f,
            groundPos);
        m_basicMeshes->DrawPlaneMesh();
    }

    // Barrel: metal
    SetShaderTexture("metal");
    SetShaderMaterial("metal");
    SetTextureUVScale(1.0f, 1.0f);
    {
        glm::vec3 scaleC(1.0f, 3.0f, 1.0f);
        glm::vec3 posC(1.5f, 1.5f, 0.0f); // center
        SetTransformations(scaleC, 0, 0, 90.0f, posC);
        m_basicMeshes->DrawCylinderMesh(true, true, true);
    }

    // Legs: plain white
    m_pShaderManager->setIntValue(g_UseTextureName, 0);
    SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
    {
        glm::vec3 legS(0.1f, 1.0f, 0.1f);
        std::vector<glm::vec3> legs = { {-1.0f,0.5f,-1.0f},{1.0f,0.5f,-1.0f},{-1.0f,0.5f,1.0f},{1.0f,0.5f,1.0f} };
        for (auto& p : legs) {
            SetTransformations(legS, 0, 0, 0, p);
            m_basicMeshes->DrawBoxMesh();
        }
    }

    // Smokestack: metal
    SetShaderTexture("metal");
    SetShaderMaterial("metal");
    SetTextureUVScale(1.0f, 1.0f);
    {
        glm::vec3 stkS(0.2f, 0.8f, 0.2f);
        glm::vec3 stkP(-1.4f, 2.4f, 0.0f);
        SetTransformations(stkS, 0, 0, 0, stkP);
        m_basicMeshes->DrawCylinderMesh(true, true, true);
    }

    // Firebox: brick
    SetShaderTexture("brick");
    SetShaderMaterial("brick");
    SetTextureUVScale(2.0f, 2.0f);
    {
        glm::vec3 fbS(1.0f, 1.0f, 0.8f);
        glm::vec3 fbP(2.0f, 1.5f, 0.0f);
        SetTransformations(fbS, 0, 0, 0, fbP);
        m_basicMeshes->DrawBoxMesh();

        /**********************************************************/
        // 7) Swimming‐pool container (box for base + sides)
        //    A single box scaled up to form the pool walls & floor
        SetShaderTexture("water");      // or use a new “poolWall” texture
        SetShaderMaterial("water");    // gives it a concrete look
        SetTextureUVScale(3.0f, 1.0f);   // tile the wall texture
        {
            // scale: X=5 wide, Y=2 tall, Z=3 deep
            glm::vec3 poolScale(5.0f, 2.0f, 3.0f);
            // position: behind grill at Z = –5, lifted by half‐height (1.0f)
            glm::vec3 poolPos(-8.0f, -0.5f, -5.0f);
            SetTransformations(poolScale, 0, 0, 0, poolPos);
            m_basicMeshes->DrawBoxMesh();
        }

        /**********************************************************/
        // 8) Water surface (flat plane with blue color/texture)
        //    sits just inside the top of the pool box
        m_pShaderManager->setIntValue("bUseTexture", 0);   // turn off texturing
        SetShaderMaterial("pool");              
        {
            // scale: slightly smaller than pool box (so it rests inside)
            glm::vec3 waterScale(10.0f, 2.0f, 3.0f);
            // position: at the very top of the box (pool height = 2.0f)
            glm::vec3 waterPos(-8.0f, 0.05f, -5.0f);
            SetTransformations(waterScale, 0, 0, 0, waterPos);
            m_basicMeshes->DrawPlaneMesh();
        }
    }
}
