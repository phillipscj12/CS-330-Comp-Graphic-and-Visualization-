﻿#pragma once

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <string>
#include <vector>

#include "ShaderManager.h"
#include "../3DShapes/ShapeMeshes.h"

static const int MAX_TEXTURES = 16;

struct TextureRecord {
    GLuint      ID;
    std::string tag;
};

struct OBJECT_MATERIAL {
    std::string tag;

    // ambient term
    glm::vec3 ambientColor;     // the color that the material reflects for ambient lighting
    float     ambientStrength;  // how strongly it reflects ambient light

    // diffuse & specular
    glm::vec3 diffuseColor;
    glm::vec3 specularColor;
    float     shininess;
};

class SceneManager {
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    void PrepareScene();
    void RenderScene();

private:
    // textures
    TextureRecord                  m_textureIDs[MAX_TEXTURES];
    size_t                         m_loadedTextures;  // number of textures loaded

    // materials
    std::vector<OBJECT_MATERIAL>   m_objectMaterials;

    // external helpers
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    // texture management
    bool  CreateGLTexture(const char* filename, std::string tag);
    void  BindGLTextures();
    void  DestroyGLTextures();
    int   FindTextureID(std::string tag);
    int   FindTextureSlot(std::string tag);

    // material lookup
    bool  FindMaterial(std::string tag, OBJECT_MATERIAL& outMat);

    // shader-uniform setters
    void  SetTransformations(
        glm::vec3 scaleXYZ,
        float rotXdeg,
        float rotYdeg,
        float rotZdeg,
        glm::vec3 posXYZ
    );
    void  SetShaderColor(float r, float g, float b, float a);
    void  SetShaderTexture(std::string tag);
    void  SetTextureUVScale(float u, float v);
    void  SetShaderMaterial(std::string tag);
   
    void LoadSceneTextures();
    void DefineObjectMaterials();
    void SetupSceneLights();
};
