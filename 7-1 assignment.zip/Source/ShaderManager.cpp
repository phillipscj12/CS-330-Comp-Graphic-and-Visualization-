///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and setting of shader code
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <sstream>

using namespace std;

#include <stdlib.h>
#include <string.h>

#include <GL/glew.h>

#include "ShaderManager.h"
#include "../Projects/6-2_Assignment/Source/LightStructs.h"

/***********************************************************
 *  LoadShaders()
 ***********************************************************/
GLuint ShaderManager::LoadShaders(const char* vertex_file_path, const char* fragment_file_path) {
	// Create the shaders
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read Vertex Shader code
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if (VertexShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << VertexShaderStream.rdbuf();
		VertexShaderCode = sstr.str();
		VertexShaderStream.close();
	}
	else {
		printf("Impossible to open %s\n", vertex_file_path);
		getchar();
		return 0;
	}

	// Read Fragment Shader code
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if (FragmentShaderStream.is_open()) {
		std::stringstream sstr;
		sstr << FragmentShaderStream.rdbuf();
		FragmentShaderCode = sstr.str();
		FragmentShaderStream.close();
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;

	// Compile Vertex Shader
	printf("Compiling shader : %s...", vertex_file_path);
	const char* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);
	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> ErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &ErrorMessage[0]);
		printf("\n%s\n", &ErrorMessage[0]);
	}
	printf("success\n");

	// Compile Fragment Shader
	printf("Compiling shader : %s...", fragment_file_path);
	const char* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);
	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0) {
		std::vector<char> ErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &ErrorMessage[0]);
		printf("\n%s\n", &ErrorMessage[0]);
	}
	printf("success\n");

	// Link the shader program
	printf("Linking shader program...");
	GLuint ProgramID = glCreateProgram();
	m_programID = ProgramID;
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);
	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 1) {
		std::vector<char> ErrorMessage(InfoLogLength + 1);
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ErrorMessage[0]);
		printf("\n%s\n", &ErrorMessage[0]);
	}
	printf("success\n");

	// Cleanup
	glDetachShader(ProgramID, VertexShaderID);
	glDetachShader(ProgramID, FragmentShaderID);
	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	return ProgramID;
}

/***********************************************************
 *  setDirectionalLight()
 ***********************************************************/
void ShaderManager::setDirectionalLight(const DirectionalLight& light) {
	this->setVec3Value("dirLight.direction", light.direction);
	this->setVec3Value("dirLight.ambient", light.ambient);
	this->setVec3Value("dirLight.diffuse", light.diffuse);
	this->setVec3Value("dirLight.specular", light.specular);
	this->setBoolValue("dirLight.bActive", light.bActive);
}

/***********************************************************
 *  setPointLight()
 ***********************************************************/
void ShaderManager::setPointLight(int index, const PointLight& light) {
	std::string prefix = "pointLights[" + std::to_string(index) + "].";
	this->setVec3Value(prefix + "position", light.position);
	this->setVec3Value(prefix + "ambient", light.ambient);
	this->setVec3Value(prefix + "diffuse", light.diffuse);
	this->setVec3Value(prefix + "specular", light.specular);
	this->setBoolValue(prefix + "bActive", light.bActive);
}
