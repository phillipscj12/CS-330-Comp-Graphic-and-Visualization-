#ifndef LIGHT_STRUCTS_H
#define LIGHT_STRUCTS_H

#include <glm/glm.hpp>

// Struct to define a directional light's properties
struct DirectionalLight {
    glm::vec3 direction;
    glm::vec3 ambient;
    glm::vec3 diffuse;
    glm::vec3 specular;
    bool bActive;
};

// Struct to define a point light's properties
struct PointLight {
    glm::vec3 position;
    glm::vec3 ambient;
    glm::vec3 diffuse;
    glm::vec3 specular;
    bool bActive;
};

#endif // LIGHT_STRUCTS_H

